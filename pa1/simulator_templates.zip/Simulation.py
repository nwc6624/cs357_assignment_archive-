import random
from Animal import Animal
from Bear import Bear
from Fish import Fish

# random.seed(42)    # Change this number for your different tests.

class Ecosystem():
    def __init__(self, size):
        """ Constructor for the Ecosystem
        It initializes the river (a list with a given size)
        It calls the method to initialize the river with animals in random places
        """
        # Remove pass and write your code here
        pass
        self.initialize_random_ecosystem()


    def initialize_random_ecosystem(self):
        """ Method to randomly initialize the ecosystem
        Randomly picks a number between 1 and 4 to decide the number of Bears
        Randomly places the Bears in the river in empty positions
        Randomly picks a number between 1 and 4 to decide the number of Fish
        Randomly places the Fish in the river in empty positions
        """
        # Remove pass and write your code here
        pass

    def animal_creation(self, type_of_animal):
        """Method to create a new type of animal when two animals of the same type collides
        The new created animal is placed randomly in the river in any empty position
        """
        # Remove pass and write your code here
        pass

    def show(self):
        """Method to show each position in the river and the animal each position contains
        """
        # Remove pass and write your code here
        pass


    def simulate(self, iterations):
        """Method to simulate the Ecosystem movement
        It similates the ecosystem live depending on the number of iterations passe as argument
        In each iteration, it processes in order each animal
        It randomly picks an action (0=move, 1=stay)
        It moves the animal and do all the similation as defined in the scenario.
            It checks if the next position is empty to move the animal
            If the position is not empty, then it checks what type of animal is in the next position
                It decides what action to perform based on the type of animal in the next position
        """
        print("~~~ Initializing the Simulation ~~~")
        # Write your code here
             

    def create_new_animal(self, a):
        """Optional Method
        You can optionally use this method to get the animal's class name
        before you use the method animal_creation()
        """
        # Remove pass and Write your code here
        pass