class Animal:

    def __init__(self):
        """
        Constructor for the Amimal.
        Every animal has a location and name
        """
        pass

    def __str__(self):
        """Method used to print the name o the animal and its location
        """
        pass

    def _move(self, new_location):
        """ Method to set the new location
        """
        pass

    def _get_location(self):
        """ Method to return the location
        """
        pass

    def get_class_name(self):
        """ Method to return the class name
        """
        pass

    def speak(self):
        """Method that allows the animal to speak
        """
        print("\tIt says: *Silence...*")